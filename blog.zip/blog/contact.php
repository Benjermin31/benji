<?php require("script.php"); ?>

<?php 
if(isset($_POST['submit'])){

    if(empty($_POST['email']) || empty($_POST['name']) || empty($_POST['email']) || empty($_POST['subject']) || empty($_POST['inquiry'])){

        $response = "All fields are required";
    }else{
        $response = sendMail($_POST['name'],$_POST['email'],$_POST['subject'],$_POST['inquiry']);
    }
}

?>
<section class="ftco-section">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="wrapper">
                <div class="row no-gutters">
                    <div class="col-lg-8 col-md-7 order-md-last d-flex align-items-stretch">
                        <div class="contact-wrap w-100 p-md-5 p-4">
                            <h3 class="mb-4">Get in touch</h3>
                                <div id="form-message-warning" class="mb-4">All fields a required</div>
                                    <div id="form-message-success" class="mb-4">Your message was sent, thank you!</div>
    <form action="" method="POST" id="contactForm" name="contactForm" class="contactForm" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="label" for="name">Full Name</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Name">
                </div>
            </div>
            <div class="col-md-6"> 
                <div class="form-group">
                    <label class="label" for="email">Email Address</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label class="label" for="subject">Subject</label>
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label class="label" for="Inquiry">Inquiry</label>
                    <textarea name="inquiry" class="form-control" id="inquiry" cols="30" rows="4" placeholder="Inquiry"></textarea>
                </div>
            </div>
            <div class="col-md-12 my-2"></div>
            <div class="col-md-12">
                <div class="form-group">
                    <input type="submit" value="Send" name="submit" class="btn btn-primary">
                        <div class="submitting"></div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
        <div class="col-lg-4 col-md-5 d-flex align-items-stretch">
            <div class="info-wrap bg-primary w-100 p-md-5 p-4">
                <h3>Let's get in touch</h3>
                <p class="mb-4">We're open for any suggestion or just to have a chat</p>
        <div class="dbox w-100 d-flex align-items-start">
            <div class="text pl-3">
            <p><span>Address:</span> FORT PORTAL CITY, KABAROLE DISTRICT</p>
        </div>
        </div>
        <div class="dbox w-100 d-flex align-items-center">
            <div class="text pl-3">
            <p><span>Phone:</span> <a href="tel://1234567920">+256-750-609-110</a></p>
        </div>
        </div>
        <div class="dbox w-100 d-flex align-items-center">
            <div class="text pl-3">
            <p><span>Email:</span> <a href="mailto:communitytourismoutlook@gmail.com">communitytourismoutlook@gmail.com</a></p>
        </div>
            </div>
                </div>
                    </div>
                            </div>
                                    </div>
                                        </div>
                                            </div>
                                                </div>
                                                </div>
        </section>
        <?php
        include 'partials/footer.php';
        ?>