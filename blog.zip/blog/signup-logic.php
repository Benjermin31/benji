<?php
require 'config/database.php';

//Get SignUp Form Data
if(isset($_POST['submit'])) {
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $username = filter_var($_POST['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $createpassword = filter_var($_POST['createpassword'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $confirmpassword = filter_var($_POST['confirmpassword'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $avatar = $_FILES['avatar'];

    //validate input data
    if (!$firstname) {
        $_SESSION['signup'] = "Firstname required";
    }elseif (!$lastname) {
        $_SESSION['signup'] = "Lastname required!";
    }elseif (!$username) {
        $_SESSION['signup'] = "Username required!";
    }elseif (!$email) {
        $_SESSION['signup'] = "Enter valid E-mail!";
    }elseif (strlen($createpassword) < 8 || strlen($confirmpassword) < 8) {
        $_SESSION['signup'] = "Password should 8+ characters.";
    }elseif (!$avatar['name']) {
        $_SESSION['signup'] = "Avatar required!";
    } else {
        // checking for password mismatch
        if ($createpassword !== $confirmpassword) {
            $_SESSION['signup'] = "Passwords do not much.";
        }else {
            //Hashing Passwords
            $hashed_password = password_hash($createpassword, PASSWORD_DEFAULT);

            //validate Existence of Username or E-mail
            $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email'";
            $user_check_result = mysqli_query($connection, $user_check_query);
            if(mysqli_num_rows($user_check_result) > 0) {
                $_SESSION['signup'] = "Username or E-mail already registered.";
            }else {
                //Renaming Avatar
                //Unique timestamps
                $time = time();
                $avatar_name = $time . $avatar['name'];
                $avatar_tmp_name = $avatar['tmp_name'];
                $avatar_destination_path = 'images/' . $avatar_name;

                //Image validation
                $allowed_files = ['png', 'jpg', 'jpeg', 'webp'];
                $extention = explode('.', $avatar_name);
                $extention = end($extention);

                if(in_array($extention, $allowed_files)) {
                    //Validate image size
                    if($avatar['size'] < 1000000) {
                        move_uploaded_file($avatar_tmp_name, $avatar_destination_path);
                    }else {
                        $_SESSION['signup'] = "File must not exceed 1MB.";
                    }
                } else {
                    $_SESSION['signup'] = "File should be png, jpg, jpeg or webp";
                }
            }
        }
    }

    // ERROR?? Redirect to Signup
    if(isset($_SESSION['signup'])) {

        //Pass back Data after refresh
        $_SESSION['signup-data'] = $_POST;
        header('location: ' . ROOT_URL . 'signup.php');
        die();
    }else {
        $insert_user_query = "INSERT INTO users SET firstname='$firstname', lastname='$lastname', username='$username', email='$email', password='$hashed_password', avatar='$avatar_name', is_admin=0";
        $insert_user_result = mysqli_query($connection, $insert_user_query);

        if(!mysqli_errno($connection)) {

            //Redirecting to SIGN IN page
            $_SESSION['signup-success'] = "Registration Successful. Please Sign in.";
            header('location: ' . ROOT_URL . 'signin.php');
            die();
        }
    }

}else {
    //Bounce back to signUp page
    header(('location: ' . ROOT_URL . 'signup.php'));
    die();
}
