<?php

define('MAILHOST', "smtp.gmail.com");
define('USERNAME', "communitytourismoutlook@gmail.com");
define('PASSWORD', "rcjpmnqvuipqqzaq");
define('SEND_FROM',$_POST["email"]);
define('addAddress', "communitytourismoutlook@gmail.com");
define('ReplyTo', $_POST["name"]);
