<?php
    include 'partials/header.php';
    ?>
    <section class="">
    <div class="header">
        <h1>Reliable, efficient Tourism</h1>
        <h1>Powered by Community Tourism Outlook</h1>
    
        <p>Lets take you on a journey of local tourism. See the hidden treasures of western Uganda and the breath
            taking scenaries of nature as you absorb the culture of the natives.
        </p>
        </div>
        <div class="row1-container">
        <div class="box box-down cyan">
            <h2>Accommodation</h2>
            <p>Monitors activity to identify project roadblocks</p>
            <img src="/images/1710148019kyaninga-lodge.jpg" alt="">
        </div>
    
        <div class="box red">
            <h2>Art & Craft</h2>
            <p>Scans our talent network to create the optimal team for your project</p>
            <img src="/images/1710148298crafts.jpg" alt="">
        </div>
    
        <div class="box box-down blue">
            <h2>Dinning</h2>
            <p>Uses data from past projects to provide better delivery estimates</p>
            <img src="/images/1710148447dinning.jpg" alt="">
        </div>
        </div>
        <div class="row2-container">
                <div class="box orange">
            <h2>Transport</h2>
            <p>Regularly evaluates our talent to ensure quality</p>
            <img src="/img/transport.jpg" alt="">
        </div>
        </div>
</div>
    </section>
    <?php
include 'partials/footer.php';
?>