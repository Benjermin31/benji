<footer>
            <div class="footer__socials">
                <a href="https://youtube.com/@CommunityTourismOutlook?si=GH24U1w8lcfgoCA-" target="_blank"><i class="uil uil-youtube"></i></a>
                <a href="https://www.facebook.com/profile.php?id=61559661805395&mibextid=ZbWKwL" target="_blank"><i class="uil uil-facebook"></i></a>
                <a href="https://www.tiktok.com/@c.t.outlook?_t=8mE7gAPdrjp&_r=1" target="_blank"><i class="uil uil-Tik tok"></i></a>
                <a href="https://x.com/CTOutlook?t=KiNV0acY3HagNDHcY0-JRw&s=09" target="_blank"><i class="uil uil-twitter"></i></a>
            </div>
            <div class="container footer__container">
                <article>
                    <h4>Location</h4>
                    <p>
                Community Tourism Outlook <br>P.O.Box 814,
                    Karambi North Division <br>
                    Fort-Portal Tourism city
                    </p>
                </article>
                <article>
                    <h4>Contact</h4>
                    <p>
                    Dr. Muhumuza Moses +256750609110<br>
                        Email: info@cto.com
                    </p>
                </article>
                <article>
                    <h4>Subscribe</h4>
                    <p>
                Community Tourism Outlook P.O. Box 814,
                    Karambi North Division<br>
                    Fort-Portal Tourism city
                    </p>
                </article>
            </div>
            <div class="footer__copyright">
                <small>Copyright &copy; 2024 COMMUNITY TOURSIM OUTLOOK</small>
            </div>
        </footer>
    <script src="<?= ROOT_URL ?>js/main.js"></script>
    </body>
</html>