<?php
require 'config/constants.php';
//Destroy all sessions and redirect to home in page
session_destroy();
header('location: ' . ROOT_URL);
die();