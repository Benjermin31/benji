<?php
session_start();
define('ROOT_URL', 'http://localhost:8080/blog/');
define('DB_HOST', 'localhost');
define('DB_USER', 'Rwenzori_Magazine');
define('DB_PASS', 'Rwenzori1234');
define('DB_NAME', 'Rwenzori_blog_db');
