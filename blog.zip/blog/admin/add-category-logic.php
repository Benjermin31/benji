<?php
require 'config/database.php';

if(isset($_POST['submit'])) {
    $title = filter_var($_POST['title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $description = filter_var($_POST['description'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);    //Validate Form Data
    if(!$title) {
        $_SESSION['add-category'] = "Enter Title.";
    } elseif (!$description) {
        $_SESSION['add-category'] = "Enter Description.";
    }

    if(isset($_SESSION['add-category'])) {
        $_SESSION['add-category-data'] = $_POST;
        header('location: ' . ROOT_URL . 'admin/add-category.php');    //Redirect back to add category page incase of Invalid input
        die();
    } else {
        $query = "INSERT INTO categories (title, description) VALUES ('$title', '$description')";        //inserting Category into database
        $result = mysqli_query($connection, $query);
        if(mysqli_errno($connection)) {
            $_SESSION['add-category'] = "Could not add category";
            header('location: ' . ROOT_URL . 'admin/add-category.php');
            die();
        } else {
            $_SESSION['add-category-success'] = "Category $title added successfully";
            header('location: ' . ROOT_URL . 'admin/manage-categories.php');
            die();
        }
    }
}