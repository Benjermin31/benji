<?php
require 'config/database.php';

//Get Add User Form Data

if(isset($_POST['submit'])) {
    $firstname = filter_var($_POST['firstname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $lastname = filter_var($_POST['lastname'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $username = filter_var($_POST['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $createpassword = filter_var($_POST['createpassword'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $confirmpassword = filter_var($_POST['confirmpassword'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $is_admin = filter_var($_POST['userrole'], FILTER_SANITIZE_NUMBER_INT);
    $avatar = $_FILES['avatar'];
    if (!$firstname) {
        $_SESSION['add-user'] = "Firstname required.";
    } elseif (!$lastname) {
        $_SESSION['add-user'] = "Lastname required.";    //validate input data
    } elseif (!$username) {
        $_SESSION['add-user'] = "Username required.";
    } elseif (!$email) {
        $_SESSION['add-user'] = "Enter valid E-mail.";
    } elseif (strlen($createpassword) < 8 || strlen($confirmpassword) < 8) {
        $_SESSION['add-user'] = "Password should 8+ characters.";
    } elseif (!$avatar['name']) {
        $_SESSION['add-user'] = "Avatar required!";
    } else {
        if ($createpassword !== $confirmpassword) {
            $_SESSION['signup'] = "Passwords do not much."; // checking for password mismatch
        } else {
            $hashed_password = password_hash($createpassword, PASSWORD_DEFAULT);            //Hashing Passwords
            $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email'";
            $user_check_result = mysqli_query($connection, $user_check_query);              //validate Existence of Username or E-mail
            if(mysqli_num_rows($user_check_result) > 0) {
                $_SESSION['add-user'] = "Username or E-mail already registered.";  //Unique timestamps  //Renaming Avatar
            } else {
                $time = time();
                $avatar_name = $time . $avatar['name'];
                $avatar_tmp_name = $avatar['tmp_name'];
                $avatar_destination_path = '../images/' . $avatar_name;
                $allowed_files = ['png', 'jpg', 'jpeg', 'webp']; //Image validation
                $extention = explode('.', $avatar_name);
                $extention = end($extention);
                if(in_array($extention, $allowed_files)) {
                    if($avatar['size'] < 1000000) {
                        move_uploaded_file($avatar_tmp_name, $avatar_destination_path);
                    } else {
                        $_SESSION['add-user'] = "File must not exceed 1MB.";  //Validate image size
                    }
                } else {
                    $_SESSION['add-user'] = "File should be png, jpg, jpeg or webp";
                }
            }
        }
    }
    if(isset($_SESSION['add-user'])) {
        $_SESSION['add-user-data'] = $_POST;
        header('location: ' . ROOT_URL . '/admin/add-user.php');    // ERROR?? Redirect to add-user
        die();
    } else {
        $insert_user_query = "INSERT INTO users SET firstname='$firstname', lastname='$lastname', username='$username', email='$email',
        password='$hashed_password', avatar='$avatar_name', is_admin=$is_admin";
        $insert_user_result = mysqli_query($connection, $insert_user_query);            //Pass back Data after refresh
        if(!mysqli_errno($connection)) {
            $_SESSION['add-user-success'] = "New User $firstname $lastname added successfully.";
            header('location: ' . ROOT_URL . 'admin/manage-users.php'); //Redirecting to manage-users page
            die();
        }
    }
}else {
    header(('location: ' . ROOT_URL . 'admin/add-user.php'));         //Bounce back to add-user page
    die();
}
