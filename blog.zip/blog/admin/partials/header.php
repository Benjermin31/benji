<?php
require '../partials/header.php';

// check login status
If(!isset($_SESSION['user-id'])) {
    header('location: ' . ROOT_URL . 'signin.php');
    die();
}